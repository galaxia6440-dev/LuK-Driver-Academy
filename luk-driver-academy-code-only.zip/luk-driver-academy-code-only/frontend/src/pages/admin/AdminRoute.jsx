import { Navigate } from "react-router-dom";

export default function AdminRoute({ children }) {
  const token = window.localStorage.getItem("luk_admin_token");
  if (!token) return <Navigate to="/admin/login" replace />;
  return children;
}
